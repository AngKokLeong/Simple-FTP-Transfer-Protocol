#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>

#include "command.h"

void execute_command(){
    int read_cmd = 1;
    while(read_cmd == 1){
        printf("Please enter your command: ");
        char user_command[100];
        scanf("%s", user_command);

        char path[100]; 
        strcpy(path,"/bin/");

        strcat(path, user_command);

        int status;
        status = execl(path, path, NULL);
        if(status == -1){
            printf("Error! Invalid command for: %s\n", user_command);
        }
    }
}