#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>

#include "command.h"

int main(void){
    execute_command();
    //gcc -o main main.c command.c
    //./main
    return 0;
}